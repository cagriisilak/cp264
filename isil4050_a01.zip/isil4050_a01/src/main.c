/**
 * -------------------------------------
 * @file  main.c
 * Assignment 1 Main Source Code File
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2023-09-07
 *
 * -------------------------------------
 */
#include <stdlib.h>
#include <stdio.h>

#include "functions.h"

int main(int argc, char *argv[]) {
	setbuf(stdout, NULL);

	// Your code here

	return 0;
}
